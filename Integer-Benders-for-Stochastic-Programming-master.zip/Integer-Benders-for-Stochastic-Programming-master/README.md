# Integer-Benders-for-Stochastic-Programming
ISE705 (large scale linear programming) project.  Lshape with integer and benders cut for the multiple knapsack stochastic program
